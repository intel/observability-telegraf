#!/bin/sh

nvme gen-hostnqn
