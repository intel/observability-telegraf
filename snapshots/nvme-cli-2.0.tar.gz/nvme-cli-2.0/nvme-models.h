#ifndef NVME_MODEL_H
#define NVME_MODEL_H

char *nvme_product_name(int id);

#endif
