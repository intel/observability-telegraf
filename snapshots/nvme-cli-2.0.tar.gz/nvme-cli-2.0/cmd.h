#ifndef _CMD_H
#define _CMD_H

#undef PLUGIN
#define PLUGIN(n, c)

#undef COMMAND_LIST
#define COMMAND_LIST(args...)

#endif
